<?php
// error_reporting(0);
/**
 * Author: Minhazul Abedin
 */

class Frontend {

 public $db_connect;

    function __construct() {
        $this->db_connect = mysqli_connect("localhost", "root", "", "blog_site") or die("Database Conenction Error");
    }

    function get_homepage_blog()
    {
        $sql = "SELECT * FROM blog ORDER BY timestamp DESC LIMIT 5";
        if($result = mysqli_query($this->db_connect, $sql))
        {
            return $result;
        }else{
            die("Query Problem");
        }
    }
    
    function check_blog_by_id($id)
    {
        $sql = "SELECT * FROM blog WHERE blog_id = $id";
        if($result = mysqli_query($this->db_connect, $sql))
        {
            $count = mysqli_num_rows($result);
            return $count;
        }else{
            die("Query Problem");
        }
    }

function check_category_by_id($id)
    {
        $sql = "SELECT * FROM category WHERE category_id = $id";
        if($result = mysqli_query($this->db_connect, $sql))
        {
            $count = mysqli_num_rows($result);
            return $count;
        }else{
            die("Query Problem");
        }
    }

            
    function get_blog_by_id($id)
    {
        if($this->check_blog_by_id($id) == 1){
            $sql = "SELECT * FROM blog WHERE blog_id = $id";
            if($return = mysqli_query($this->db_connect, $sql))
            {
                $result = mysqli_fetch_assoc($return);
                return $result;
            }else{
                die("Query Problem");
            }
        } else {
            header("Location: ./");
        }

    }
    

function get_categories_by_id($id)
    {
        if($this->check_category_by_id($id) == 1){
            $sql = "SELECT * FROM category WHERE category_id = $id";
            if($return = mysqli_query($this->db_connect, $sql))
            {
                $result = mysqli_fetch_assoc($return);
                return $result;
            }else{
                die("Query Problem");
            }
        } else {
            header("Location: ./");
        }

    }
    

    function get_categories()
    {
        $sql = "SELECT * FROM category WHERE action=1";
        if($data = mysqli_query($this->db_connect, $sql)){
            
            return $data;
        }else{
                die("Query Problem");
            }
    }


function pagination(){
      $sql="SELECT* FROM blog";
      $result= mysql_query($this->db_connect,$sql);
      $total_rows=mysqli_num_rows($result);
        $total_page=ceil($total_rows/$total_page);

    }

    function limit_text($text, $limit) {
      if (str_word_count($text, 0) > $limit) {
          $words = str_word_count($text, 2);
          $pos = array_keys($words);
          $text = substr($text, 0, $pos[$limit]) . '...';
      }
      return $text;
    }



    function add_comment($request)
    {
        $sql = "INSERT INTO   contact (name,email,subject) VALUES('$request[name]','$request[email]','$request[subject]')";
        if($sql = mysqli_query($this->db_connect, $sql)){
            return true;
            $msg="commment have inserted";
        }
     else{
            die("Query Problem");
        }
    }

    function search($value)
    {
        $sql="SELECT *FROM blog WHERE blog_title LIKE '$value'";
        if($data = mysqli_query($this->db_connect, $sql))
        {
            return $data;
        }else
        {
            die("Query Problem");
        }
    }

    function recent_posts()
    {
        $sql="SELECT *FROM blog WHERE blog_title=0 ORDER BY blog_id DESC LIMIT 5";
        
        if($data = mysqli_query($this->db_connect, $sql))
        {
            return $data;
        }else
        {
            die("Query Problem");
        }
    }
}
