<?php
$page = "search_content";
include 'index.php';
?>