<?php
include './class/frontend.class.php';
$obj = new Frontend;
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Decoders Lab</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Business_Blog Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
        Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
        <script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <link href="assets/css/bootstrap.css" rel='stylesheet' type='text/css' />
        <!-- Custom Theme files -->
        <link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
        <link href="assets/css/style.css" rel='stylesheet' type='text/css' />
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
    </head>
    <body>
        <?php
        include './includes/header.php';
        ?>
        <?php
        include './includes/banner.php';
        ?>
        
        <div class="technology">
            <div class="container">
                <?php
                if (isset($page)) {
                switch ($page) {
                case "search_content":
                include './includes/search_content.php';
                break;

                case "blog_details":
                include './includes/blog_details_content.php';
                break;
                  case "category_details":
                include './includes/category_details_content.php';
                break;
                

                default :
                include './includes/home_content.php';
                break;
                }
                } else {
                include './includes/home_content.php';
                }
                ?>
           
    <?php
    include './includes/sidebar_details_content.php';
    
    ?>
    
            </div>
        </div>
        <?php
        include './includes/footer.php';
        ?>
    </body>
</html>