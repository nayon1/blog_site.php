<div class="row">
	<div class="col-md-4">
		<?php
		while ($blog_info=mysqli_fetch_asoos($result)) {
			# code..?>
	</div>
<div class="gird">
<a href="blog_details.php?id=<?php echo $blog_info['blog_id'];?>"><?php echo $blog_info['blog_title'];?>

	<a href="blog_title.php?id=<?php echo $blog_info['blog_id']?>"><?php echo $blog_info['blog_title'];?></a>
	<a href="blog_info.php?id=<?php echo $blog_root['blog_id'] ;?>"><?php echo $blog_root['blog_details']?></a>
</div>
	<div class="mout">
		<div class="gird_view">
			<div class="rooot">
				<a href="blog_details.php?id=<?php echo $blog_info[;blog_root];?>"><?php echo $blog_root['blog_info']?>
			</div>
		</div>
	</div>
	</div>
	<div class="row_metal">
		<div class="row">
			<div class="col-md-4">
			<p> <a href="blog_info.php?id=<?php echo $blog_root['blog_info'];?>"></p>

			
			</div>
		</div>
	</div>