<?php
$page = "sidebar_details";
include 'index.php';

