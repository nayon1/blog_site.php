<?php
$page = "blog_details";
include 'index.php';

