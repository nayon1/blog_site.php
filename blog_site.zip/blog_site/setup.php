<?php
session start ();

if (isset($_COOKIE['loggedin'])) {
    unset($_COOKIE['username']);
    
	setcookie('loggedin', '', time()-1300); 
	setcookie('username', '', time()-1300); 	
} 
echo "<script>window.open('404.php','_self')</script>";
?>