<?php
if(empty($page)){
?>    
<!-- banner -->
        <div class="banner">
            <div class="container">
                
                <h2>আপনাকে স্বাগতম </h2>
                <p>টিম এরর ! নতুন কিছুর  খোজে</p>
              
            </div>
        </div>
<?php }else{?>

<div class="banner1">
	
</div>
<?php } ?>
