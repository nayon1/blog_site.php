<?php
$result = $obj->recent_posts();
?>
<div class="col-md-3 technology-right">
	<div class="blo-top">
		<div class="tech-btm">
			<img src="assets/images/banner1.jpg" class="img-responsive" alt=""/>
		</div>
	</div>
	<div class="blo-top">
		<div class="tech-btm">
			<h4>সাইন ইন করুন </h4>
			<p>Pellentesque dui, non felis. Maecenas male</p>
			<div class="name">
				<form>
					<input type="text" placeholder="Email" required="">
				</form>
			</div>
			<div class="button">
				<form>
					<input type="submit" value="Subscribe">
				</form>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<div class="blo-top1">
		<div class="tech-btm">
			<h4>সম্প্রতি</h4>
			<div class="blog-grids">
				<div class="blog-grid-left">
					<?php while ($blog_info = mysqli_fetch_assoc($result)){
					?>
					 <a href="blog_details.php?id=<?php echo $blog_info['blog_id'];?>"><img src="./admin/assets/upload/<?php echo $blog_info['blog_image'];?>" class="img-responsive" alt=""/></a>
				</div>
				<div class="blog-grid-right">
				
					<h5><a href="blog_details.php?id=<?php echo $blog_info['blog_id'];?>"> <?php echo $blog_info['blog_title'];?></a></h5>
					</br>
					</br>
					<?php }?>
					
				</div>
				<div class="clearfix"> </div>
				
			</div>
			</div>
			</div>
			</div>
