<div class="wrap">
		<div class="feed">
			<div class="feedback">
			   <h1>FEEDBACK</h1>
			   <form>
				   <label>NAME</label>
				   <input type="text" value="" id="name">
				   <label>E-MAIL</label>
				   <input type="text" value="">
				   <label>SUBJECT</label>
				   <textarea> </textarea><br>
				   <input type="submit" value="Submit">
			   </form>
			</div>
		
		<div class="clear"></div>
		</div>
