<?php

if (isset($_GET['search'])) {
    $result = $obj->search($_GET['search']);
    if (count($result) == 0) {
      $error = 'Sorry no result found';
    }
    // if (is_numeric($_GET['id'])) {
    //   $result = $obj->get_blog_by_id($_GET['id']);

    // }else{
    //         header("Locaion: ./");
    // }
}else{
    header("Locaion: ./");
}
?>

<div class="col-md-9 technology-left">
    <div class="tech-no">
        <?php
        while ($blog_info = mysqli_fetch_assoc($result)){
        ?>
        <!-- technology-top -->
        <div class="soci">
            <ul>
                <li><a href="#" class="facebook-1"> </a></li>
                <li><a href="#" class="facebook-1 twitter"> </a></li>
                <li><a href="#" class="facebook-1 chrome"> </a></li>
                <li><a href="#"><i class="glyphicon glyphicon-envelope"> </i></a></li>
                <li><a href="#"><i class="glyphicon glyphicon-print"> </i></a></li>
                <li><a href="#"><i class="glyphicon glyphicon-plus"> </i></a></li>
            </ul>
        </div>
        <div class="tc-ch">

            <div class="tch-img">
                <a href="blog_details.php?id=<?php echo $blog_info['blog_id'];?>"><img src="./admin/assets/upload/<?php echo $blog_info['blog_image'];?>" class="img-responsive" alt=""/></a>
            </div>
            <a class="blog blue" href="blog_details.php">Technology</a>
            <h3><a href="blog_details.php?id=<?php echo $blog_info['blog_id'];?>"><?php echo $blog_info['blog_title'];?></a></h3>
            </br>
         <a href="blog_details.php?id=<?php echo $blog_info['blog_id'];?>"><?php echo substr($blog_info['blog_description'],0,500);?>
            <div class="blog-poast-info">
                <ul>
                    <li><i class="glyphicon glyphicon-user"> </i><a class="admin" href="#"> Admin </a></li>
                    <li><i class="glyphicon glyphicon-calendar"> </i>30-12-2015</li>
                    <li><i class="glyphicon glyphicon-comment"> </i><a class="p-blog" href="#">3 Comments </a></li>
                    <li><i class="glyphicon glyphicon-heart"> </i><a class="admin" href="#">5 favourites </a></li>
                    <li><i class="glyphicon glyphicon-eye-open"> </i>1.128 views</li>
                </ul>
            </div>
        </div>
        <div class="clearfix"></div>
        <?php }?>
        
    </div>
</div>
