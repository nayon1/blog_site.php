<div class="footer">
    <div class="container">
        <div class="col-md-4 footer-left">
            <h6>টিম এরর </h6>
            <p>নতুন কিছুর দেবার অপেক্ষাই </p>
            <p> ডেভেলপ বাই টিম এরর </p>
        </div>
        <div class="col-md-4 footer-middle">
            <h4>যোগাযোগ </h4>
            <div class="mid-btm">
                <p>টিম এরর অফিস </p>
                <p>বাউন্ডারি রোড, মিরপুর ২ , ঢাকা </p>
                <a href="ফর মোর "></a>
            </div>

            <p></p>
            <p></p>
            <a href="https://w3layouts.com/"></a>

        </div>
        <div class="col-md-4 footer-right">
            <h4>আর</h4>
            <li><a href="#">হোম </a></li>
            <li><a href="#">সম্প্রতি  </a></li>
            <li><a href="#">ফুটবল </a></li>
            <li><a href="#"> ক্রিকেট </a></li>
            <li><a href="#">রাজনীতি  </a></li>
            <li><a href="#">সব</a></li>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<div class="copyright">
    <div class="container">
        <p>© ২০১৮ . All rights reserved | Template by <a href="http://w3layouts.com/">টিম এরর</a></p>
    </div>
</div>
