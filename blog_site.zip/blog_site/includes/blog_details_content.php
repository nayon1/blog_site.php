<?php
if (isset($_GET['id'])) {
    if (is_numeric($_GET['id'])) {
        $result = $obj->get_blog_by_id($_GET['id']);
    }else{
            header("Locaion: ./");
    }
}else{
    header("Locaion: ./");
}
?>
<div class="col-md-9 technology-left">
    <div class="business">
        <div class=" blog-grid2">
            <img src="images/1.jpg" class="img-responsive" alt="">
            <div class="blog-text">
                <h5><?php echo $result['blog_title'];?></h5>
                <p>
                    <?php echo $result['blog_description'];?>
                </p>				
            </div>
        </div>
        
        
        <?php

if ($_SERVER['REQUEST_METHOD']=='POST'){
// $name=$nm->validation($POST['name']);
// $email=$em->validation($POST['email']);
// $subject=$sub->validation($POST['subject']);

$name=mysqli_real_escape_string($obj->db_connect, $_POST['name']);
$email=mysqli_real_escape_string( $obj->db_connect,$_POST['email']);
$subject=mysqli_real_escape_string( $obj->db_connect,$_POST['subject']);



 $obj->add_comment($_POST);
// $error="";
// if (empty($name)) {
//   $error="name must not empty";
// }else if (empty($email)) {
//     $error="email must not be empty";
// }else if (!filter_var($email,FILTER_VALIDATION_EMAIL)) {
//   $error="email an invlid";
// }else if (empty($subject)) {
//         $error="body must not be empty(var)";
// }else{

//         $query="INSERT INTO  contact (name,email,subject) VALUES('$name,$email,$subject')";
//     if ($inserted_rows) {
//      $msg="message sent sucesfully"; # code...
//     }

//     else{
//       $msg="have not sent";
//     }
//       }
  }

?>

        <div class="comment">
            <h3>Leave a Comment</h3>
            <div class=" comment-bottom">
                <form action="" method="POST" >
                    <input type="text" value="" placeholder="Name" name="name">
                    <input type="text" value="" placeholder="Email" name="email">
                  
                    <textarea name="subject" value="subject"  placeholder="Message" required=""></textarea>
                    <input type="submit" value="submit" name="submit">
                </form>
            </div>
        </div>
    </div>
</div>