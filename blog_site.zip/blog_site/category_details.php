<?php
$page = "category_details";
include 'index.php';
?>

