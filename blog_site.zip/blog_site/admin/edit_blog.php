<?php 
$site = 'edit_blog';
include "index.php";
?>