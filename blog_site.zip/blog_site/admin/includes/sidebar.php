

<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">

            <li>
                <a href="./" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
            </li>
                        <li>
            <a href="./catagories_blog.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Add Catagories</span> </a>
            </li>
              <li>
            <a href="./manage_catagorey.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Manage Catagories</span> </a>
            </li>
            
            <li>
                <a href="./add_blog.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Add Blog</span> </a>
            </li>
            <li>
                <a href="./manage_blog.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Manage Blog</span> </a>
            </li>
            <li>
                <a href="./setting.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Setting</span> </a>
            </li>


            
        </ul>
    </div>
</div>