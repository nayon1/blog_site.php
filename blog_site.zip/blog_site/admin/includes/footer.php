
<div class="copy">
    <p> &copy; 2017. All Rights Reserved  !! <a> degisned and devloped by mithen & sohag</a>  </p>
    <p><a>copy right  showed not be allowed without admin permission !! tnx</a> </p>
    </div>