<?php
$retun = $obj->get_admin_info();
$admin = mysqli_fetch_assoc($retun);
?>
<div id="page-wrapper" class="gray-bg dashbard-1">
    <div class="content-main">
        <!--banner-->	
        <div class="banner">
            <h2>
                <a href="index.html">Home</a>
                <i class="fa fa-angle-right"></i>
                <span>Profile</span>
            </h2>
        </div>
        <!--//banner-->
        <!--gallery-->
        <div class=" profile">

            <div class="profile-bottom">
                <h3><i class="fa fa-user"></i>Profile</h3>
                <div class="profile-bottom-top">
                    <div class="col-md-4 profile-bottom-img">
                              <img src="../admin/assets/images /in10.jpg <?php echo $get_admin_info['blog_image']; ?>" style="width: 200px;">
                        <!--<img src="images/in10.jpg" alt="">-->
                    </div>
           
                    <div class="col-md-8 profile-text">
                        <h6><?php echo $admin['admin_name']; ?></h6>
                        <table>
                            <tr><td>Email</td>  
                                <td>:</td>  
                                <td><?php echo $admin['admin_email']; ?>
                                </td>
                            </tr>
                            <tr><td></td>  
                                <td></td>  
                                <td>
                                    <button id="btn_change" class="btn btn-success">Change Password</button>
                                    <form method="post" id="changePass" style="display: none;">
                                        <div class="col-md-12 form-group1 group-mail">
                                            <label class="control-label">Old Password</label>
                                            <input name="old_pass" type="password" placeholder="Enter Previous Password" required="">
                                        </div>
                                        <div class="col-md-12 form-group1 group-mail">
                                            <label class="control-label">New Password</label>
                                            <input name="new_pass" id="new_pass" type="password" placeholder="Enter New Password" required="">

                                        </div>
                                        <div class="col-md-12 form-group1 group-mail">
                                            <label class="control-label">Confirm Password</label>
                                            <input name="new_pass" id="confirm_pass" type="password" placeholder="Enter Confirm Password" required="">

                                        </div>
                                        
                                        <div class="clearfix"> </div>

                                        <div class="col-md-12 form-group">
                                            <button name="btn" type="submit" class="btn btn-primary">Submit</button>
                                            <button type="button" id="cancel" class="btn btn-default">Cancel</button>
                                        </div>
                                    </form>
                                </td>
                            </tr>

                        </table>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="profile-btn">

                    <button type="button" href="#" class="btn bg-red">Save changes</button>
                    <div class="clearfix"></div>
                </div>


            </div>
        </div>
    </div>

</div>
<script>
    $("#btn_change").on('click', function () {
        $("#changePass").css("display", "block");
        $("#btn_change").css("display", "none");
    });
    $("#cancel").on('click', function () {
        $("#changePass").css("display", "none");
        $("#btn_change").css("display", "block");
    });
    $("#confirm_pass").on("keyup", function () {
        var new_pass = $("#new_pass").val();
        var confirm_pass = $("#confirm_pass").val();
        if (new_pass != confirm_pass)
        {
            $("#confirm_pass").css("background-color","#ff9999");
        }
        if (new_pass == confirm_pass)
        {
            $("#confirm_pass").css("background-color","");
        }
    });
    $("#changePass").on("submit",function(){
        $.post("change_password.php", function(data, status){
            alert("Data: " + data + "\nStatus: " + status);
        });
    });
</script>