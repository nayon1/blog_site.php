<?php
$result = $obj->get_all_category();

if (isset($_GET['action']) && isset($_GET['category_id'])) {
    if ($_GET['action'] == "delete") {
        if (!empty($_GET['category_id']) && is_numeric($_GET['category_id'])) {
            $obj->delete_category($_GET['category_id']);
        } else {
            header("Location: ./");
        }
    }
}
if (isset($_GET['msg'])) {
    $return = $_GET['msg'];
}
?>
<div id="page-wrapper" class="gray-bg dashbard-1">
    <div class="content-main">

        <!--banner-->	
        <div class="banner">
            <h2>
                <a href="index.html">Home</a>
                <i class="fa fa-angle-right"></i>
                <span>Manage Blog</span>
            </h2>
        </div>
        <div class="blank">
            <div class="blank-page">
<?php if (isset($return)) { ?>
                    <h2>
    <?php
    if (is_array($return)) {
        foreach ($return as $value) {
            echo $value;
        }
    } else {
        echo $return;
    }
    ?>
                    </h2>
                    <?php } ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>                    
                            <td></td>
                            <td>Title</td>
                            <td>Description</td>
                            <td>Status</td>
                            <td>Action</td>
                        </tr>
                    </thead>
                    <tbody>
<?php
while ($category = mysqli_fetch_assoc($result)) {
    ?>
                            <tr>
                                <td></td>
                                <td><?php echo $category['category_name']; ?></td>
                                <td><?php echo $category['category_description']; ?></td>
                                <td><?php echo $category['action'] ? "Publish" : "Unpublish"; ?></td>

                                <td>
                                    <a href="./edit_manage_category.php?category_id=<?php echo $category['category_id']; ?>" class="btn btn-default">EDIT</a>
                                    <a href="?action=delete&category_id=<?php echo $category['category_id']; ?>" class="btn btn-default">Delete</a>
                                </td>

                            </tr>
<?php } ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>