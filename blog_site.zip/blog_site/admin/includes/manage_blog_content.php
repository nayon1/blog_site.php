<?php
$result = $obj->get_all_blogs();
if (isset($_GET['action']) && isset($_GET['blog_id'])) {
    if ($_GET['action'] == "delete") {
        if (!empty($_GET['blog_id']) && is_numeric($_GET['blog_id'])) {
            $obj->delete_blog($_GET['blog_id']);
        } else {
            header("Location: ./");
        }
    }
}
if(isset($_GET['msg']))
{
    $return = $_GET['msg'];
}
?>
<div id="page-wrapper" class="gray-bg dashbard-1">
    <div class="content-main">

        <!--banner-->	
        <div class="banner">
            <h2>
                <a href="index.html">Home</a>
                <i class="fa fa-angle-right"></i>
                <span>Manage Blog</span>
            </h2>
        </div>
        <div class="blank">
            <div class="blank-page">
                <?php if (isset($return)) { ?>
                    <h2>
                        <?php
                        if (is_array($return)) {
                            foreach ($return as $value) {
                                echo $value;
                            }
                        } else {
                            echo $return;
                        }
                        ?>
                    </h2>
                <?php } ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>                    
                            <td></td>
                            <td>Title</td>
                            <td>Description</td>
                            <td>Status</td>
                            <td>Created</td>
                            <td>Action</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($blog = mysqli_fetch_assoc($result)) {
                            ?>
                            <tr>
                                <td></td>
                                <td><?php echo $blog['blog_title']; ?></td>
                                <td><?php echo $blog['blog_description']; ?></td>
                                <td><?php echo $blog['action'] ? "Publish" : "Unpublish"; ?></td>
                                <td><?php echo date('d-M-Y H:i', strtotime($blog['timestamp'])); ?></td>
                                <td>
                                    <a href="./edit_blog.php?blog_id=<?php echo $blog['blog_id']; ?>" class="btn btn-default">EDIT</a>
                                    <a href="?action=delete&blog_id=<?php echo $blog['blog_id']; ?>" class="btn btn-default">Delete</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>