
<?php if (isset($_POST['btn'])) {
    $return = $obj->add_category($_POST);
}
?>
<div id="page-wrapper" class="gray-bg dashbard-1">
    <div class="content-main">

        <!--banner-->	
        <div class="banner">
            <h2>
                <a href="index.html">Home</a>
                <i class="fa fa-angle-right"></i>
                <span>Add Catagory</span>
            </h2>
        </div>
        <!--//banner-->
        <!--grid-->
        <div class="validation-system">

            <div class="validation-form">
                <!---->

                <?php if (isset($return)) { ?>
                    <h2>
                        <?php
                        if (is_array($return)) {
                            foreach ($return as $value) {
                                echo $value;
                            }
                        } else {
                            echo $return;
                        }
                        ?>
                    </h2>
                <?php } ?>
                <form method="post" action=""  enctype="multipart/form-data">

                    <div class="col-md-12 form-group1 group-mail">
                        <label class="control-label">Title</label>
                        <input name="title" type="text" placeholder="Write Blog Title Here.." required="">
                    </div>
                    <div class="clearfix"> </div>
                    <div class="col-md-12 form-group1 ">
                        <label class="control-label">catagories Description</label>
                        <textarea name="description" placeholder="Blog Descriptiton..." required=""></textarea>
                    </div>
                   
                    <div class="clearfix"> </div>

                    <div class="col-md-12 form-group2 group-mail">
                        <label class="control-label">Action</label>
                        <select name="action">
                            <option value="1" selected>Publish</option>
                            <option value="0">Unpublish</option>
                        </select>
                    </div>
                    <div class="clearfix"> </div>

                    <div class="col-md-12 form-group">
                        <button name="btn" type="submit" class="btn btn-primary">Submit</button>
                        <button type="reset" class="btn btn-default">Reset</button>
                    </div>
                    <div class="clearfix"> </div>
                </form>

                <!---->
            </div>

        </div>
    </div>
</div>

