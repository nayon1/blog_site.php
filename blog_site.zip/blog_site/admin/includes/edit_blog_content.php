<?php
if (isset($_GET['blog_id'])) {
    if (is_numeric($_GET['blog_id'])) {
        $blog_info = mysqli_fetch_assoc($obj->get_blog_by_id($_GET['blog_id']));
    }
} else {
    header('Location: ./');
}
if (isset($_POST['btn'])) {
    $return = $obj->update_blog($_POST);
}
?>
<div id="page-wrapper" class="gray-bg dashbard-1">
    <div class="content-main">

        <!--banner-->	
        <div class="banner">
            <h2>
                <a href="index.html">Home</a>
                <i class="fa fa-angle-right"></i>
                <span>Edit Blog</span>
            </h2>
        </div>
        <!--//banner-->
        <!--grid-->
        <div class="validation-system">

            <div class="validation-form">
                <!---->

<?php if (isset($return)) { ?>
                    <h2>
                    <?php
                    if (is_array($return)) {
                        foreach ($return as $value) {
                            echo $value;
                        }
                    } else {
                        echo $return;
                    }
                    ?>
                    </h2>
                    <?php } ?>
                <form method="post" action=""  enctype="multipart/form-data">

                    <div class="col-md-12 form-group1 group-mail">
                        <label class="control-label">Title</label>
                        <input name="blog_id" type="hidden" value="<?php echo $blog_info['blog_id']; ?>">
                        <input name="title" type="text" value="<?php echo $blog_info['blog_title']; ?>" placeholder="Write Blog Title Here.." required="">
                    </div>
                    <div class="clearfix"> </div>
                    <div class="col-md-12 form-group1 ">
                        <label class="control-label">Blog Description</label>
                        <textarea name="description" placeholder="Blog Descriptiton..." required=""><?php echo $blog_info['blog_description']; ?></textarea>
                    </div>
                    <div class="clearfix"> </div>
                    <div class="col-md-12 form-group1 ">
                        <label class="control-label">Upload Image</label><br>
                        <img  src="./assets/upload/<?php echo $blog_info['blog_image']; ?>" class="img-thumbnail" style="max-height: 200px;">
                        <br>
                        <input name="blog_image" type="file" id="exampleInputFile">
                        <p class="help-block">Upload only JPG,PNG images.Max Size 5mb.</p>
                    </div>
                    <div class="clearfix"> </div>

                    <div class="col-md-12 form-group2 group-mail">
                        <label class="control-label">Action</label>
                        <select name="action">
                            <option value="1" <?php echo ($blog_info['action']==1)?"selected":"";?>>Publish</option>
                            <option value="0" <?php echo ($blog_info['action']==0)?"selected":"";?>>Unpublish</option>
                        </select>
                    </div>
                    <div class="clearfix"> </div>

                    <div class="col-md-12 form-group">
                        <button name="btn" type="submit" class="btn btn-primary">Update</button>
                        <button type="reset" class="btn btn-default">Reset</button>
                    </div>
                    <div class="clearfix"> </div>
                </form>

                <!---->
            </div>

        </div>
    </div>
</div>
