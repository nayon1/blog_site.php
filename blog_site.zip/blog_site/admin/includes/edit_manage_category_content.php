<?php
if (isset($_GET['category_id'])) {
    if (is_numeric($_GET['category_id'])) {
        $category_info = mysqli_fetch_assoc($obj->get_category_by_id($_GET['category_id']));
    }
} else {
    header('Location: ./');
}
if (isset($_POST['btn'])) {
    $return = $obj->update_category($_POST);
}
?>
<div id="page-wrapper" class="gray-bg dashbard-1">
    <div class="content-main">

        <!--banner-->	
        <div class="banner">
            <h2>
                <a href="index.html">Home</a>
                <i class="fa fa-angle-right"></i>
                <span>Update category</span>
            </h2>
        </div>
        <!--//banner-->
        <!--grid-->
        <div class="validation-system">

            <div class="validation-form">
                <!---->

                <?php if (isset($return)) { ?>
                    <h2>
                        <?php
                        if (is_array($return)) {
                            foreach ($return as $value) {
                                echo $value;
                            }
                        } else {
                            echo $return;
                        }
                        ?>
                    </h2>
                <?php } ?>
                <form method="post" action=""  enctype="multipart/form-data">

                    <div class="col-md-12 form-group1 group-mail">
                        <label class="control-label">name</label>
                        <input name="category_id" type="hidden" value="<?php echo $category_info['category_id']; ?>">
                        <input name="name" type="text" value="<?php echo $category_info['category_name']; ?>"  placeholder="Write Blog Title Here.." required="">
                    </div>
                    <div class="clearfix"> </div>
                    <div class="col-md-12 form-group1 ">
                        <label class="control-label">category Description</label>
                        <textarea name="description"   placeholder="category Descriptiton..." required=""><?php echo $category_info['category_description']; ?></textarea>
                    </div>
                    
                    <div class="clearfix"> </div>

                    <div class="col-md-12 form-group2 group-mail">
                        <label class="control-label">Action</label>
                        <select name="action">
                            <option value="1" selected>Publish</option>
                            <option value="0">Unpublish</option>
                        </select>
                    </div>
                    <div class="clearfix"> </div>

                    <div class="col-md-12 form-group">
                        <button name="btn" type="submit" class="btn btn-primary">Submit</button>
                        <button type="reset" class="btn btn-default">Reset</button>
                    </div>
                    <div class="clearfix"> </div>
                </form>

                <!---->
            </div>

        </div>
    </div>
</div>
