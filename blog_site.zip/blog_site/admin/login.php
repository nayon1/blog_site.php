<?php
session_start();
if (isset($_SESSION['login_id'])) {
    header("Location: ./");
}
include "./class/admin_function.class.php";
$obj = new Admin;

if (isset($_POST['btn'])) {
	$return  = $obj->login_admin($_POST['email'],$_POST['password']);

	if ($return) {
		
		$_SESSION['login_id'] = uniqid();
		header("Location:./"); 
	 } else{
		$msg = "Wrong Login Information";
	}
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Minimal an Admin Panel Category Flat Bootstrap Responsive Website Template | Signin :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="./assets/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="./assets/css/style.css" rel='stylesheet' type='text/css' />
<link href="./assets/css/font-awesome.css" rel="stylesheet"> 
<script src="./assets/js/jquery.min.js"> </script>
<script src="./assets/js/bootstrap.min.js"> </script>
</head>
<body>
	<div class="login">
		<h1><a href="index.html">Minimal </a></h1>
		<div class="login-bottom">
			<h2>Login</h2>
			<h2><?php if(isset($msg)){echo $msg;}?></h2>
			<form method="post" action="">
			<div class="col-md-6">
				<div class="login-mail">
					<input name="email" type="text" placeholder="Email" required="">
					<i class="fa fa-envelope"></i>
				</div>
				<div class="login-mail">
					<input name='password' type="password" placeholder="Password" required="">
					<i class="fa fa-lock"></i>
				</div>
				   <a class="news-letter " href="#">
						 <label class="checkbox1"><input type="checkbox" name="checkbox" ><i> </i>Forget Password</label>
					   </a>

			
			</div>
			<div class="col-md-6 login-do">
				<label class="hvr-shutter-in-horizontal login-sub">
					<input name="btn" type="submit" value="login">
					</label>
				
				
			</div>
			
			<div class="clearfix"> </div>
			</form>
		</div>
	</div>
		<!---->
<div class="copy-right">
            <p> &copy; 2016 Minimal. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>	    </div>  
<!---->
<!--scrolling js-->
	<script src="./assets/js/jquery.nicescroll.js"></script>
	<script src="./assets/js/scripts.js"></script>
	<!--//scrolling js-->
</body>
</html>

