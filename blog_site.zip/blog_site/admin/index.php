<?php
ob_start();
session_start();
if (!isset($_SESSION['login_id'])) {
    header("Location: ./login.php");
}
include "./class/admin_function.class.php";
$obj = new Admin;
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Minimal an Admin Panel Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <link href="./assets/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
        <!-- Custom Theme files -->
        <link href="./assets/css/style.css" rel='stylesheet' type='text/css' />
        <link href="./assets/css/font-awesome.css" rel="stylesheet"> 
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <!-- Mainly scripts -->
        <script src="./assets/js/jquery.metisMenu.js"></script>
        <script src="./assets/js/jquery.slimscroll.min.js"></script>
        <!-- Custom and plugin javascript -->
        <link href="./assets/css/custom.css" rel="stylesheet">
        <script src="./assets/js/custom.js"></script>
        <script src="./assets/js/screenfull.js"></script>
        <script>
$(function () {
    $('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

    if (!screenfull.enabled) {
        return false;
    }



    $('#toggle').click(function () {
        screenfull.toggle($('#container')[0]);
    });



});
        </script>

        <!----->

        <!--skycons-icons-->
        <script src="./assets/js/skycons.js"></script>
        <!--//skycons-icons-->
    </head>

    <body>
        <!-- Header Start -->
        <div id="wrapper">
            <?php
            include "includes/header.php";
            ?>  
        </div>
        <!-- Header Ends -->
        <?php
        include "includes/sidebar.php";
        ?>  





        <?php
        if (isset($site)) {
            switch ($site) {
                case 'home':
                    include "./includes/home_content.php";
                    break;
                case 'add_blog':
                    include "./includes/add_blog_content.php";
                    break;
                case 'manage_blog':
                    include "./includes/manage_blog_content.php";
                    break;
                case 'edit_blog':
                    include "./includes/edit_blog_content.php";
                    break;
                 case 'catagories_blog':
                    include "./includes/catagories_blog_content.php";
                    break;
                  case 'manage_catagorey':
                    include "./includes/manage_category_content.php";
                    break;
                 case 'edit_manage_category':
                    include "./includes/edit_manage_category_content.php";
                    break;
                case 'setting':
                    include "./includes/setting_content.php";
                    break;

                default:
                    include "./includes/home_content.php";
                    break;
            }
        } else {
            include "./includes/home_content.php";
        }
        ?>

        <?php
        include "includes/footer.php";
        ?>