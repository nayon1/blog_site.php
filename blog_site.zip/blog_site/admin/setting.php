<?php 
$site = 'setting';
include "index.php";
?>