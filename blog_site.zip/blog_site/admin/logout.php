<?php
session_start();
if (isset($_SESSION['login_id'])) {
    session_unset();
    header("Location: ./");
}else{
	header("Location: ./");
}
?>