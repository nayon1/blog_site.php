<?php

if($_POST){
    echo "<pre>";
    print_r($_POST);
} else {
    echo 'No data';
}

