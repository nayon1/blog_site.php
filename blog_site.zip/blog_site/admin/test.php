<?php

function get_all_blogs() {
    $sql = "SELECT * FROM blog";
    if ($data = mysqli_query(mysqli_connect("localhost", "root", "", "blog_site"), $sql)) {
        return $data;
    } else {
        die("Query Error - ") . mysqli_error($this->db_connect);
    }
}
echo '<pre>';
print_r(mysqli_fetch_assoc(get_all_blogs()));
print_r(mysqli_fetch_array(get_all_blogs()));
?>