
<?php 
$site = 'catagories_blog';
include "index.php";
?>