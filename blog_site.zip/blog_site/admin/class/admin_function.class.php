<?php

// error_reporting(0);
/**
 * Author: Minhazul Abedin
 */
class Admin {

    private $db_connect;

    function __construct() {
        $this->db_connect = mysqli_connect("localhost", "root", "", "blog_site") or die("Database Conenction Error");
    }

    function login_admin($email, $password) {
        $password = md5($password);
        $sql = "SELECT * FROM admin_user WHERE admin_email = '$email' AND admin_password = '$password'";

        if ($result = mysqli_query($this->db_connect, $sql)) {
            if (mysqli_num_rows($result) == 1) {
                return true;
            } else {
                return false;
            }
        }
    }

    function add_blog($data) {
        $directory = "../admin/assets/upload/";
        if (!dir($directory)) {
            die("Directory Not Found");
        }

        $path = $_FILES['blog_image']['name'];
        $ext = pathinfo($path, PATHINFO_EXTENSION);
        $image_name = uniqid() . "." . $ext;
        $target_file = $directory . "/" . $image_name;

        $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
        $file_size = $_FILES['blog_image']['size'];
        $is_image = getimagesize($_FILES['blog_image']['tmp_name']);

        if ($is_image) {
            if (file_exists($target_file)) {
                return 'This file Already exists';
                exit();
            } else {
                if ($file_size > 5242880) {
                    return 'File Size is Too Large.Please select a size within 5mb';
                    exit();
                } else {
                    if ($file_type != 'jpg' && $file_type != 'png') {
                        die("File type is not vaild");
                    } else {

                        if (move_uploaded_file($_FILES['blog_image']['tmp_name'], $target_file)) {
                            $sql = "INSERT INTO blog (blog_title,blog_description,action,blog_image) VALUES ('$data[title]','$data[description]','$data[action]','$image_name')";
                            if (mysqli_query($this->db_connect, $sql)) {
                                $msg = "Blog Saved Sucessfully";
                                return $msg;
                            } else {
                                return mysqli_error($this->db_connect);
                            }
                        } else {
                            die("Product Image Upload Error");
                        }
                    }
                }
            }
        } else {
            echo 'This is not a image';
        }
    }

    function get_all_blogs() {
        $sql = "SELECT * FROM blog";
        if ($data = mysqli_query($this->db_connect, $sql)) {
            return $data;
        } else {
            die("Query Error - ") . mysqli_error($this->db_connect);
        }
    }
     function get_all_category() {
        $sql = "SELECT * FROM category";
        if ($data = mysqli_query($this->db_connect, $sql)) {
            return $data;
        } else {
            die("Query Error - ") . mysqli_error($this->db_connect);
        }
    }

    function get_blog_by_id($id) {
        $sql = "SELECT * FROM blog WHERE blog_id='$id'";
        if ($data = mysqli_query($this->db_connect, $sql)) {
            return $data;
        } else {
            return mysqli_error($this->db_connect);
        }
    }

    function update_blog($data) {
        if ($_FILES['blog_image']['size'] == 0) {
            $sql = "UPDATE blog SET blog_title='$data[title]',blog_description='$data[description]',action='$data[action]' WHERE blog_id='$data[blog_id]'";
            if (mysqli_query($this->db_connect, $sql)) {
                $msg = "Blog Updated Sucessfully";
                header('Location: ./manage_blog.php?msg='.$msg);
            } else {
                return mysqli_error($this->db_connect);
            }
        } else {
            $directory = "../admin/assets/upload/";
            if (!dir($directory)) {
                die("Directory Not Found");
            }

            $path = $_FILES['blog_image']['name'];
            $ext = pathinfo($path, PATHINFO_EXTENSION);
            $image_name = uniqid() . "." . $ext;
            $target_file = $directory . "/" . $image_name;

            $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
            $file_size = $_FILES['blog_image']['size'];
            $is_image = getimagesize($_FILES['blog_image']['tmp_name']);

            if ($is_image) {
                if (file_exists($target_file)) {
                    return 'This file Already exists';
                    exit();
                } else {
                    if ($file_size > 5242880) {
                        return 'File Size is Too Large.Please select a size within 5mb';
                        exit();
                    } else {
                        if ($file_type != 'jpg' && $file_type != 'png') {
                            return "File type is not vaild";
                            exit();
                        } else {

                            if (move_uploaded_file($_FILES['blog_image']['tmp_name'], $target_file)) {
                                $sql = "UPDATE blog SET blog_title='$data[title]',blog_description='$data[description]',blog_image='$image_name',action='$data[action]' WHERE blog_id='$data[blog_id]'";
                                if (mysqli_query($this->db_connect, $sql)) {
                                    $msg = "Blog Saved Sucessfully";
                                    header('Location: ./manage_blog.php?msg='.$msg);
                                } else {
                                    return mysqli_error($this->db_connect);
                                }
                            } else {
                                return "Blog Image Upload Error";
                            }
                        }
                    }
                }
            } else {
                return 'This is not a image';
            }
        }
    }
    
     function get_category_by_id($id) {
        $sql = "SELECT * FROM category WHERE category_id='$id'";
        if ($data = mysqli_query($this->db_connect, $sql)) {
            return $data;
        } else {
            die("Query Error - ") . mysqli_error($this->db_connect);
        }
    }
    
    
    function update_category($data) {
        $sql = "UPDATE category SET category_name='$data[name]',category_description='$data[description]',action='$data[action]' WHERE category_id='$data[category_id]'";
        if ($data = mysqli_query($this->db_connect, $sql)) {
            $msg = "category updated Sucessfully";
            header("Location: ./manage_catagorey.php?msg=" . $msg);
        } else {
            die("Query Error - ") . mysqli_error($this->db_connect);
        }
    }

    
    function delete_category($id) {
        $sql = "DELETE FROM category WHERE category_id='$id'";
        if ($data = mysqli_query($this->db_connect, $sql)) {
            $msg = "Category Deleted Sucessfully";
            header("Location:./manage_catagorey.php?msg=" . $msg);
        } else {
            die("Query Error - ") . mysqli_error($this->db_connect);
        }
    }


    function delete_blog($id) {
        $sql = "DELETE FROM blog WHERE blog_id='$id'";
        if ($data = mysqli_query($this->db_connect, $sql)) {
            $msg = "Blog Deleted Sucessfully";
            header("Location: ./manage_blog.php?msg=" . $msg);
        } else {
            die("Query Error - ") . mysqli_error($this->db_connect);
        }
    }

    function get_admin_info() {
        $sql = "SELECT * FROM admin_user WHERE user_name='admin'";
        if ($data = mysqli_query($this->db_connect, $sql)) {
            return $data;
        } else {
            die("Query Error - ") . mysqli_error($this->db_connect);
        }
    }

    function add_category($data) {
        $sql = "INSERT INTO category (category_name,category_description,action) VALUES ('$data[title]','$data[description]','$data[action]')";

        if ($data = mysqli_query($this->db_connect, $sql)) {
            $msg = "Catgory Added Sucessfully";
            return $msg;
        } else {
            die("Query Error - ") . mysqli_error($this->db_connect);    
        }
    }

}
?> 




