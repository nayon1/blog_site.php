<?php 
$site = 'add_blog';
include "index.php";
?>