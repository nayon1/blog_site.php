<?php 
$site = 'manage_blog';
include "index.php";
?>