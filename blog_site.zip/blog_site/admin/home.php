<?php 
$site = 'home';
include "index.php";
?>