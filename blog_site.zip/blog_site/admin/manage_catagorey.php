<?php 
$site = 'manage_catagorey';
include "index.php";
?>
